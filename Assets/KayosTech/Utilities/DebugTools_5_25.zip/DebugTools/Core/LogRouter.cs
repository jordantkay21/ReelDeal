using System;
using UnityEngine;
using System.Runtime.CompilerServices;

namespace KayosTech.Utilities.DebugTools
{

    [System.Serializable]
    public enum LogLevel
    {
        Internal, //Backend use only - to file/console
        Info, //Developer-readable, can show to player in dev builds
        Success, //Player-visible
        Alert, //Player-visible warning
        Error //Player-visible error
    }




    /// <summary>
    /// Captures log messages and routes them to both visual and persistent outputs
    /// </summary>
    public class LogRouter : MonoBehaviour
    {
        public static event Action<LogEntry> OnLogReceived;
        public static bool SuppressFrontendLogs { get; set; } = false;


        private void Awake()
        {
            LogFileWriter.InitializeLogFile();
        }

        private void OnApplicationQuit()
        {
            LogFileWriter.SaveLogFile();
        }

        /// <summary>
        /// Logs a message with the specified tag and level.
        /// </summary>
        /// <param name="tag">Short context descriptor (e.g., SYSTEM, NETWORK)</param>
        /// <param name="message">The body of the log message</param>
        /// <param name="level">Severity level of the log</param>
        /// <param name="callingMethod">Auto filled method name of caller</param>
        /// <param name="callingFile">Auto filled file path of caller</param>
        public static void Log(string tag, string message, LogLevel level = LogLevel.Internal, [CallerMemberName] string callingMethod = "", [CallerFilePath] string callingFile = "")
        {
            string scriptName = System.IO.Path.GetFileNameWithoutExtension(callingFile);

            float timer = level switch
            {
                LogLevel.Info => 3.0f,
                LogLevel.Success => 4.0f,
                LogLevel.Alert => 5.0f,
                LogLevel.Error => 6.0f,
                _ => 3.0f
            };

            LogEntry entry = new LogEntry
            {
                ScriptName = scriptName,
                MethodName = callingMethod,
                Level = level,
                DisplayTime = timer,
                Tag = tag,
                Message = message, 
                Timestamp = DateTime.Now
            };

            string color = LogUtility.GetColorHex(entry.Level);
            string formatted = $"<color={color}>{entry}</color>";

            //Console Logging
            switch (level)
            {
                case LogLevel.Internal:
                    Debug.Log($"{formatted}");
                    break;
                case LogLevel.Info:
                    Debug.Log($"{formatted}");
                    break;
                case LogLevel.Success:
                    Debug.Log($"{formatted}");
                    break;
                case LogLevel.Alert:
                    Debug.LogWarning($"{formatted}");
                    break;
                case LogLevel.Error:
                    Debug.LogError($"{formatted}");
                    break;
                default:
                    Debug.Log($"[UNKNOWN LEVEL] {formatted}");
                    break;
            }

            HandleFileLog(entry);

            if (!SuppressFrontendLogs)
                OnLogReceived?.Invoke(entry);
        }

        private static void HandleFileLog(LogEntry entry)
        {
            LogFileWriter.AppendToLog(entry.ToString());
        }

    }
}
